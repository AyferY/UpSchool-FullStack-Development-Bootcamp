﻿using Microsoft.AspNetCore.Identity;

namespace Domain.Identity
{
    public class UserRole:IdentityUserRole<string>
    {
    }
}
