﻿using Microsoft.AspNetCore.Identity;

namespace Domain.Identity
{
    public class RoleClaim:IdentityRoleClaim<string>
    {
    }
}
