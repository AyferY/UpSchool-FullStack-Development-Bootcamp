﻿using Microsoft.AspNetCore.Identity;

namespace Domain.Identity
{
    public class UserLogin:IdentityUserLogin<string>
    {
    }
}
