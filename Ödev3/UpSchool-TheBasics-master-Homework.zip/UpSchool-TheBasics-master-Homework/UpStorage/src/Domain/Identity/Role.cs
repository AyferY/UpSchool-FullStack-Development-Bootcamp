﻿using Microsoft.AspNetCore.Identity;

namespace Domain.Identity
{
    public class Role:IdentityRole<string>
    {
    }
}
