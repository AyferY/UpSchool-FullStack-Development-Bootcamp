﻿using Microsoft.AspNetCore.Identity;

namespace Domain.Identity
{
    public class UserToken:IdentityUserToken<string>
    {
    }
}
