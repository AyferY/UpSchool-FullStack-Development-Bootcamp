﻿using Application.Common.Interfaces;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Address.Queries.GetById
{
    //public class AddressGetByIdQueryHandler : IRequestHandler<AddressGetByIdQuery, List<AddressGetByIdDto>>
    //{
    //    private readonly IApplicationDbContext _applicationDbContext;

    //    public AddressGetByIdQueryHandler(IApplicationDbContext applicationDbContext)
    //    {
    //        _applicationDbContext = applicationDbContext;
    //    }

    //    public async Task<AddressGetByIdDto> Handle(AddressGetByIdQuery request, CancellationToken cancellationToken)
    //    {

    //    }
    //}
}
