﻿using Application.Features.Address.Queries.GetAll;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Address.Queries.GetById
{
    public class AddressGetByIdQuery : IRequest<List<AddressGetAllDto>>
    {
        public string AddressId { get; set; }

        public AddressGetByIdQuery(string AddressId)
        {
            AddressId = AddressId;
        }
    }
}
