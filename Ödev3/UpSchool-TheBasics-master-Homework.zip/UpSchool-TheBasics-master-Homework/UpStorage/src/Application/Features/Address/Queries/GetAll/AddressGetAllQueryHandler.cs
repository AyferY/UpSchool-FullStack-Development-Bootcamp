﻿using Application.Common.Interfaces;
using Domain.Entities;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Address.Queries.GetAll
{
    public class AddressGetAllQueryHandler : IRequestHandler<AddressGetAllQuery, List<AddressGetAllDto>>
    {
        private readonly IApplicationDbContext _applicationDbContext;

        public AddressGetAllQueryHandler(IApplicationDbContext applicationDbContext)
        {
            _applicationDbContext = applicationDbContext;
        }

        public async Task<List<AddressGetAllDto>> Handle(AddressGetAllQuery request, CancellationToken cancellationToken)
        {
            var dbQuery = _applicationDbContext.Addresses.AsQueryable();

            if (!string.IsNullOrEmpty(request.UserId)) dbQuery = dbQuery.Where(x => x.UserId == request.UserId);
            if (request.CountryId ==null) dbQuery = dbQuery.Where(x => x.CountryId == request.CountryId);
            if (request.CityId == null) dbQuery = dbQuery.Where(x => x.CityId == request.CityId);

            dbQuery = dbQuery.Include(x => x.City).Include(x => x.AddressType);

            var addresses = await dbQuery.ToListAsync(cancellationToken);

            var addressDtos = MapAddressesToGetAllDtos(addresses);

            return addressDtos.ToList();

        }

        private IEnumerable<AddressGetAllDto> MapAddressesToGetAllDtos(List<Domain.Entities.Address> addresses)
        {
            List<AddressGetAllDto> addressGetAllDtos = new List<AddressGetAllDto>();

            foreach (var address in addresses)
            {

                yield return new AddressGetAllDto()
                {
                    Id = Convert.ToInt32(address.Id),
                    CityId = address.CityId,
                    UserId = address.UserId,
                    AddressLine1 = address.AddressLine1,
                    AddressLine2 = address.AddressLine2,
                    PostCode = address.PostCode,
                    District = address.District,
                    AddressType = address.AddressType.ToString(),
                    Name = address.Name,
                    CountryId = address.CountryId,
                };
            }
        }

    }
}