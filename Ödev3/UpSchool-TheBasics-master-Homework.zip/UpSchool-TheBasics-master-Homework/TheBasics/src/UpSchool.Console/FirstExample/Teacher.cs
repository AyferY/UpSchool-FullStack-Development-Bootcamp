﻿namespace UpSchool.Console.FirstExample
{
    public class Teacher : PersonBase, ITurkishPerson
    {
        public string TCID { get; set; }
    }
}
