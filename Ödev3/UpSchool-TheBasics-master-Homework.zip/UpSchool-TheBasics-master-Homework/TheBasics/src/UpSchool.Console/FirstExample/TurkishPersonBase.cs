﻿namespace UpSchool.Console.FirstExample
{
    public class TurkishPersonBase
    {

    }
}
