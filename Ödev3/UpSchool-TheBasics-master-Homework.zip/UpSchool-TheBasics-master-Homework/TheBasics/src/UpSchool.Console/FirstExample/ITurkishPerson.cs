﻿namespace UpSchool.Console.FirstExample
{
    public interface ITurkishPerson
    {
        string TCID { get; set; }
    }
}
