﻿namespace UpSchool.Console.FirstExample
{
    public class Parent : PersonBase, ITurkishPerson
    {
        public string TCID { get; set; }
    }
}
