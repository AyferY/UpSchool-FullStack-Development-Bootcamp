﻿namespace UpSchool.Console.Enums
{
    public enum AccessType
    {
        FACE = 0,
        FINGERPRINT=1,
        CARD=2,
    }
}
