﻿namespace UpSchool.Console.Common
{
    public interface IEntityBase:IEntity
    {
       string Id { get; set; }
    }
}
