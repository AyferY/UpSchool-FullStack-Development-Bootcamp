﻿namespace UpSchool.Console.Common
{
    public interface IEntity
    {
    }
}
