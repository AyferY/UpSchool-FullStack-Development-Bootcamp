﻿using UpSchool.Domain.Common;

namespace UpSchool.Wasm.Common.Utilities
{
    public class ConsoleLogger:LoggerBase
    {
        public ConsoleLogger(string titanicFluteUrl):base(titanicFluteUrl)
        {
            
        }
    }
}
