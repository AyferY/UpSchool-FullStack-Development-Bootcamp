﻿using UpSchool.Domain.Common;

namespace UpSchool.Domain.Entities
{
    public class Attendee:EntityBase
    {
        public string FullName { get; set; }
    }
}
