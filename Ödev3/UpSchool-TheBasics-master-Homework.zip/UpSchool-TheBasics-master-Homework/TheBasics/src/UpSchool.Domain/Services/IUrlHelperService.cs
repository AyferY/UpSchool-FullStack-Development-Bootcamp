﻿namespace UpSchool.Domain.Services
{
    public interface IUrlHelperService
    {
        string ApiUrl { get;}
    }
}
