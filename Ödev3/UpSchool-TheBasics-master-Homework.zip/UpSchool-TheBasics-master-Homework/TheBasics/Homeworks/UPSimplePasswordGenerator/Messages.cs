﻿namespace UPSimplePasswordGenerator
{
    public static class Messages
    {
        public static class Questions
        {
            public static string IncludeNumbers => "Do u want to Include Numbers?";
            public static string IncludeLowercaseCharacters => "OK! How about lowercase characters?";
            public static string IncludeUppercaseCharacters => "Very nice! How about uppercase characters?";
            public static string IncludeSpecialCharacters => "All right! We are almost done. Would you also want to add special characters?";
            public static string PasswordLength => "Great! Lastly. How long do you want to keep your password length?";
        }
    }
}
